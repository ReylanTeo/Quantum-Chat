// server.js
const WebSocket = require('ws');

// Create a WebSocket server
const wss = new WebSocket.Server({ port: 8080 });

// Store connected clients
const clients = new Set();

// Event listener for connection
wss.on('connection', function connection(ws) {
    clients.add(ws);

    // Event listener for incoming messages
    ws.on('message', function incoming(message) {
        // Broadcast the message to all clients except the sender
        clients.forEach(function each(client) {
            if (client !== ws && client.readyState === WebSocket.OPEN) {
                client.send(message);
            }
        });
    });

    // Event listener for closing connection
    ws.on('close', function() {
        clients.delete(ws);
    });
});

console.log('Signaling server started on port 8080');
